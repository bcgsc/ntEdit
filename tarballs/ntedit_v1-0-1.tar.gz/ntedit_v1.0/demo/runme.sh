../ntEdit.pl -f ecoliWithMismatches001Indels0001.fa.gz -r solidBF_k25.bf -k 25 -d 5 -i 4 -b ntEditEcolik25 
