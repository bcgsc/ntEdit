#include <iostream>

void hello()
{
    std::cout << "Hello, world!"<< std::endl;
}
