#!/usr/bin/perl

use strict;
use warnings;

use example;

example::hello();
