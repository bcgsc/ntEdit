source /home/hmohamadi/.e7_env
/home/hmohamadi/ntHits/nthits --help
